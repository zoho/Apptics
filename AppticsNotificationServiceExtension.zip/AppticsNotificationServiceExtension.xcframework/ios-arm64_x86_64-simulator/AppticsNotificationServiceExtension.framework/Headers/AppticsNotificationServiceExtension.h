//
//  AppticsNotificationServiceExtension.h
//  AppticsNotificationServiceExtension
//
//  Created by Saravanan S on 04/10/24.
//

#import <Foundation/Foundation.h>

//! Project version number for AppticsNotificationServiceExtension.
FOUNDATION_EXPORT double AppticsNotificationServiceExtensionVersionNumber;

//! Project version string for AppticsNotificationServiceExtension.
FOUNDATION_EXPORT const unsigned char AppticsNotificationServiceExtensionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppticsNotificationServiceExtension/PublicHeader.h>

#import <AppticsNotificationServiceExtension/APPushNotificationExtension.h>

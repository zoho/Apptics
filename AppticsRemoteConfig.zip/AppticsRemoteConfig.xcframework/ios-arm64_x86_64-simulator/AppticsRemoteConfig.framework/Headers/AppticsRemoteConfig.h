//
//  AppticsRemoteConfig.h
//  AppticsRemoteConfig
//
//  Created by Saravanan S on 20/11/21.
//

#import <Foundation/Foundation.h>

//! Project version number for AppticsRemoteConfig.
FOUNDATION_EXPORT double AppticsRemoteConfigVersionNumber;

//! Project version string for AppticsRemoteConfig.
FOUNDATION_EXPORT const unsigned char AppticsRemoteConfigVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppticsRemoteConfig/PublicHeader.h>


#import "APRemoteConfig.h"
#import "APRemoteConfigValue.h"


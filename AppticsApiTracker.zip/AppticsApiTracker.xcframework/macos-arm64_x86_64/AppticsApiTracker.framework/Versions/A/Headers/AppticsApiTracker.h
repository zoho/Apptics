//
//  AppticsApiTracker.h
//  AppticsApiTracker
//
//  Created by Saravanan S on 25/11/21.
//

#import <Foundation/Foundation.h>

//! Project version number for AppticsApiTracker.
FOUNDATION_EXPORT double AppticsApiTrackerVersionNumber;

//! Project version string for AppticsApiTracker.
FOUNDATION_EXPORT const unsigned char AppticsApiTrackerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppticsApiTracker/PublicHeader.h>

#import "APAPIManager.h"

//
//  AppticsFeedbackKit.h
//  AppticsFeedbackKit
//
//  Created by Saravanan S on 29/06/22.
//

#import <Foundation/Foundation.h>

//! Project version number for AppticsFeedbackKit.
FOUNDATION_EXPORT double AppticsFeedbackKitVersionNumber;

//! Project version string for AppticsFeedbackKit.
FOUNDATION_EXPORT const unsigned char AppticsFeedbackKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppticsFeedbackKit/PublicHeader.h>

#import <AppticsFeedbackKit/FeedbackKit.h>
#import <AppticsFeedbackKit/ZAPresenter.h>
#import <AppticsFeedbackKit/FKCustomHandler.h>


import UIKit

class NonFatalListCell: UITableViewCell {

    @IBOutlet var title: UILabel!
    

}


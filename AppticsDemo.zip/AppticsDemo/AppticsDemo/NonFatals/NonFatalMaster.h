//
//  CrashMaster.h
//  AppticsDemo
//
//  Created by Saravanan S on 20/01/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NonFatalMasterObjc : NSObject

- (void)throwException;
- (void)throwError;

@end


NS_ASSUME_NONNULL_END

//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#import <Apptics/Apptics.h>
//#import <AppticsCrashKit/AppticsCrashKit.h>
//#import <AppticsEventTracker/AppticsEventTracker.h>
//#import <AppticsScreenTracker/AppticsScreenTracker.h>

#import "CrashMaster.h"
#import "NonFatalMaster.h"

#import <AppticsFeedbackKit/AppticsFeedbackKit.h>
#import <AppticsApiTracker/AppticsApiTracker.h>
#import <AppticsInAppUpdate/AppticsInAppUpdate.h>
#import <AppticsRateUs/AppticsRateUs.h>
#import <AppticsRemoteConfig/AppticsRemoteConfig.h>
#import <AppticsCrossPromotion/AppticsCrossPromotion-Swift.h>


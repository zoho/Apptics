
import UIKit

class APIListCell: UITableViewCell {
    
    @IBOutlet var title: UILabel!    

}



import UIKit

class CrashListCell: UITableViewCell {

    @IBOutlet var title: UILabel!
    

}


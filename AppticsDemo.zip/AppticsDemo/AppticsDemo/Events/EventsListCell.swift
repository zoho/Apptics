
import UIKit

class EventsListCell: UITableViewCell {

    @IBOutlet var groupTitle: UILabel!
    @IBOutlet var eventTitle: UILabel!
    

}


//
//  PromotedAppsController-Swift.h
//  ZAnalytics
//
//  Created by Prakash R on 31/08/20.
//

#ifndef PromotedAppsController_Swift_h
#define PromotedAppsController_Swift_h

@interface PromotedAppsController : UIViewController;



@end

#endif /* PromotedAppsController_Swift_h */
